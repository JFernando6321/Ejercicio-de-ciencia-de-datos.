# Informe — Prueba técnica Ciencia de Datos · Julio Vicente

## Cómo subirlo a Overleaf

1. Overleaf → **New Project → Upload Project** → arrastra este `.zip`.
2. Overleaf detecta `informe.tex` como documento principal. Si no lo hace:
   Menu → *Main document* → `informe.tex`.
3. Compilador: **pdfLaTeX** (el que trae por defecto). No requiere nada más.

## Qué contiene

```
informe.tex              Documento principal (única fuente editable)
outputs/tex/*.tex        Tablas generadas por src/13_tablas_latex.py
outputs/tex/cifras.tex   Macros con las cifras del modelo (\AUCROC, \NCampana, …)
outputs/figuras/*.png    Las cinco figuras que se insertan
```

Las tablas y las cifras **no se escriben a mano**: salen de los guiones del
análisis, de modo que si el modelo se reejecuta, el informe se actualiza sin
edición manual. Si editas en Overleaf, edita `informe.tex`; los archivos de
`outputs/` se sobrescriben en la siguiente ejecución del pipeline.

## Convención monetaria

Todos los importes están en **pesos colombianos (COP)**, en la escala original de
las bases (que no declaran unidad). Ver la nota de la sección 2.1.
